<?php

declare(strict_types=1);

namespace Elastic\Apm\Impl;

final class SrcRootDir
{
    /** @var string */
    public static $fullPath;
}
