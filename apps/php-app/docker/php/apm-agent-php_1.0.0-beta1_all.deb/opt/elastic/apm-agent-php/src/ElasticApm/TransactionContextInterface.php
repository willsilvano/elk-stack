<?php

declare(strict_types=1);

namespace Elastic\Apm;

interface TransactionContextInterface extends ExecutionSegmentContextInterface
{
}
